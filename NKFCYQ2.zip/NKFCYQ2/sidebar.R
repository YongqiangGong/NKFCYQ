sidebar <- dashboardSidebar(
  sidebarMenu(
    id = "sidebar",
    menuItem("Introduction", icon = icon("database"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ/"),
    menuItem("miRNA Analysis", icon = icon("bars"), 
             menuSubItem("miRNA-Gene Prediction", tabName = "mirna_gene_prediction"),
             menuSubItem("Gene-miRNA Prediction", tabName = "gene_mirna_prediction"),
             menuSubItem("Expression Analysis", tabName = "mirna_expression"),
             menuSubItem("Paired Expression Analysis", tabName = "paired_mirna_expression"),
             menuSubItem("Survival Analysis", tabName = "mirna_survival"),
             menuSubItem("ROC Analysis", tabName = "mirna_roc")
             ),
    menuItem("Single-gene Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ2/"),
    menuItem("Methylation Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ3/"),
    menuItem("Somatic Mutation Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ4/"),
    menuItem("Contact", icon = icon("message"), tabName = "contact"),
    menuItem("Acknowledgements", icon = icon("heart"), tabName = "Acknowledgements")
    
    
  )
)