body <- dashboardBody(
  add_busy_spinner(spin = "fading-circle"),
  tabItems(
    
    # tabItem(tabName = "communications",
    #         formUI(formInfo)
    # ),
    
    # tabItem(tabName = "acknowledgements",
    #         box(width = 12,
    #             h3("学生"),
    #             hr(),
    #             h4("龚永强 南开大学医学院"),
    #             hr(),
    #             h3("指导教师"),
    #             hr(),
    #             h4("刘寅教授 南开大学医学院")
    #         ))
    
    # mirna_expression
    tabItem(tabName = "mirna_expression",
            fluidRow(
              box(width=3,
                  
                  column(12,
                         selectInput(
                           "mirna_expression_people", 
                           label = "People", 
                           choices = clinical_vars,  # 直接使用向量
                           selected = clinical_vars[11]  # 默认选中第一个元素
                         )),
                  
                  
                  column(12,
                         selectInput(
                           "mirna_expression_mirna", 
                           label = "miRNA", 
                           choices = mir,  # 直接使用向量
                           selected = mir[1]  # 默认选中第一个元素
                         )),
                  
                  column(6,
                         actionButton("mirna_expression_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                  #                    max = 400, value = 300)
                  # )
              ),
              
              box(width = 9,
                  downloadButton("mirna_expression_download", "Download"),
                  hr(),
                  plotOutput("mirna_expression")
              )
              
            )),
    
    # paired_mirna_expression
    
    tabItem(tabName = "paired_mirna_expression",
            fluidRow(
              box(width=3,
                  
                  column(12,
                         selectInput(
                           "paired_mirna_expression_people", 
                           label = "People", 
                           choices = clinical_vars,  # 直接使用向量
                           selected = clinical_vars[11]  # 默认选中第一个元素
                         )),
                  
                  
                  column(12,
                         selectInput(
                           "paired_mirna_expression_mirna", 
                           label = "miRNA", 
                           choices = mir,  # 直接使用向量
                           selected = mir[1]  # 默认选中第一个元素
                         )),
                  
                  column(6,
                         actionButton("paired_mirna_expression_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                  #                    max = 400, value = 300)
                  # )
              ),
              
              box(width = 9,
                  downloadButton("paired_mirna_expression_download", "Download"),
                  hr(),
                  plotOutput("paired_mirna_expression")
              )
              
            )),
    
    
    # mirna_roc
    
    tabItem(tabName = "mirna_roc",
            fluidRow(
              box(width=3,
                  
                  column(12,
                         selectInput(
                           "mirna_roc_mirna", 
                           label = "miRNA", 
                           choices = mir,  # 直接使用向量
                           selected = mir[1]  # 默认选中第一个元素
                         )),
                  
                  column(6,
                         actionButton("mirna_roc_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                  #                    max = 400, value = 300)
                  # )
              ),
              
              box(width = 9,
                  downloadButton("mirna_roc_download", "Download"),
                  hr(),
                  plotOutput("mirna_roc")
              )
              
            )),
    
    
    tabItem(tabName = "mirna_survival",
            fluidRow(
              box(width=3,
                  
                  column(12,
                         selectInput(
                           "mirna_survival_people", 
                           label = "People", 
                           choices = clinical_vars,  # 直接使用向量
                           selected = clinical_vars[11]  # 默认选中第一个元素
                         )),
                  
                  column(12,
                         selectInput(
                           "mirna_survival_mirna", 
                           label = "miRNA", 
                           choices = mir,  # 直接使用向量
                           selected = mir[1]  # 默认选中第一个元素
                         )),
                  
                  column(12,
                         selectInput(
                           "mirna_survival_time", 
                           label = "Time", 
                           choices = list("1 year" = 365, "3 year" = 1095, "5 year" = 1825,"10 year" = 3650), 
                           selected = 3650  # 默认选中第一个元素
                         )),
                  
                  column(6,
                         actionButton("mirna_survival_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_survival_width", label = "Width", min = 0,
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_survival_height", label = "Height", min = 0,
                  #                    max = 500, value = 300)
                  # )
              ),
              
              box(width = 9,
                  # height = 600,
                  downloadButton("mirna_survival_download", "Download"),
                  hr(),
                  plotOutput("mirna_survival")
              )
              
            )),
    
    
    
    tabItem(tabName = "mirna_gene_prediction",
            fluidRow(
              box(width=3,
                  
                  column(12,
                         textInput("mirna_gene_prediction_mirna",
                                   label = "miRNA",
                                   value = mir[100])),
                  
                  column(6,
                         actionButton("mirna_gene_prediction_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_survival_width", label = "Width", min = 0,
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_survival_height", label = "Height", min = 0,
                  #                    max = 500, value = 300)
                  # )
              ),
              
              box(width = 9,
                  DT::dataTableOutput("mirna_gene_prediction")
              )
              
            )),
    
    
    
    
    tabItem(tabName = "gene_mirna_prediction",
            fluidRow(
              box(width=3,
                  
                  column(12,
                         textInput("gene_mirna_prediction_gene",
                                   label = "Gene",
                                   value = "TP53")),
                  
                  column(6,
                         actionButton("gene_mirna_prediction_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_survival_width", label = "Width", min = 0,
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_survival_height", label = "Height", min = 0,
                  #                    max = 500, value = 300)
                  # )
              ),
              
              box(width = 9,
                  DT::dataTableOutput("gene_mirna_prediction")
              )
              
            )),
    
    # contact
    tabItem(tabName = "contact",
            fluidRow(
              box(width = 12,
                  div(class = "intro-content",
                      h2("Contact Us"),
                      p("If you encounter any problems while using NKFCYQ, or have suggestions for improving the platform, please feel free to contact us through the following methods. We will respond to your inquiries as soon as possible."),
                      
                      div(class = "contact-method",
                          p(strong("Email:"), "gongyq@mail.nankai.edu.cn")  # 可替换为实际邮箱地址
                      ),
                      
                      div(class = "contact-method",
                          p(strong("WeChat:"), "gongyqnankai")  # 可替换为实际微信号
                      )
                  )
              )
            )),
    
    tabItem(tabName = "Acknowledgements",
            fluidRow(
              box(width = 12,
                  div(class = "intro-content",
                      h2("Acknowledgements"),
                      p("We would like to express our sincere gratitude to all individuals and organizations who have contributed to the development of NKFCYQ."),
                      
                  )
              )
            ))
    
    
    
  )
)

