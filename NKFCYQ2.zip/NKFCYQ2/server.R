# server ------------------------------------------------------------------

server <- function(input, output, session) {
  
  # 验证密码
  # res_auth <- secure_server(
  #   check_credentials = check_credentials(credentials)
  # )
  
  # communications
  # formServer(formInfo)
  
  
  # gene_expression
  observeEvent(input$mirna_expression_action,{
    
    gene <- input$mirna_expression_mirna
    people <- input$mirna_expression_people
    
    people_split<- strsplit(people, ":")[[1]]
    people_var <- people_split[1]
    people_filter <- people_split[2]
    
    boxplot_data <- mirna %>%
      dplyr::select(id,gene) %>% 
      na.omit() %>% 
      inner_join(clinical,.,by="id") %>% 
      dplyr::filter(!!sym(people_var) == people_filter)
    
    output$mirna_expression <- renderPlot({
      ggplot(boxplot_data,mapping=aes(x=tissue_type,y=!!sym(gene)))+
        stat_boxplot(geom='errorbar',
                     width=0.2,lwd=0.2)+#添加误差棒
        geom_boxplot(mapping=aes(fill=tissue_type))+
        scale_fill_manual(values = colors)+
        theme_bw(base_size = 15)+
        labs(x="Tissue type",
             y="The expression level",
             fill="Tissue type",
             title=gene)+
        ggsignif::geom_signif(
          comparisons = list(c("Normal","Tumor")),
          map_signif_level = T,#显示型号，默认是F，也就是显示P值
          textsize = 4#显著性标记字体大小
        )+
        theme(plot.title = element_text(hjust = 0.5))
      
    },
    width = as.numeric(517),
    height = as.numeric(400))
  })
  
  output$mirna_expression_download <- downloadHandler(
    filename = function() {
      paste("mirna_expression_", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      
      gene <- input$mirna_expression_mirna
      people <- input$mirna_expression_people
      
      people_split<- strsplit(people, ":")[[1]]
      people_var <- people_split[1]
      people_filter <- people_split[2]
      
      boxplot_data <- mirna %>%
        dplyr::select(id,gene) %>% 
        na.omit() %>% 
        inner_join(clinical,.,by="id") %>% 
        dplyr::filter(!!sym(people_var) == people_filter)
      
      p <- ggplot(boxplot_data,mapping=aes(x=tissue_type,y=!!sym(gene)))+
        stat_boxplot(geom='errorbar',
                     width=0.2,lwd=0.2)+#添加误差棒
        geom_boxplot(mapping=aes(fill=tissue_type))+
        scale_fill_manual(values = colors)+
        theme_bw(base_size = 15)+
        labs(x="Tissue type",
             y="The expression level",
             fill="Tissue type",
             title=gene)+
        ggsignif::geom_signif(
          comparisons = list(c("Normal","Tumor")),
          map_signif_level = T,#显示型号，默认是F，也就是显示P值
          textsize = 4#显著性标记字体大小
        )+
        theme(plot.title = element_text(hjust = 0.5))
      
      ggsave(filename = file, plot = p, 
             width = 517 / 71.5,
             height = 400 / 71.5,
             dpi = 600, units = "in")
    }
  )
  # paired_mirna_expression
  
  observeEvent(input$paired_mirna_expression_action,{
    
    gene <- input$paired_mirna_expression_mirna
    people <- input$paired_mirna_expression_people
    
    people_split<- strsplit(people, ":")[[1]]
    people_var <- people_split[1]
    people_filter <- people_split[2]
    
    paired_boxplot_data <- mirna %>%
      dplyr::select(id,gene) %>% 
      na.omit() %>% 
      inner_join(paired_clinical,.,by="id") %>% 
      dplyr::filter(!!sym(people_var) == people_filter)
    
    output$paired_mirna_expression <- renderPlot({
      ggplot(paired_boxplot_data,mapping=aes(x=tissue_type,y=!!sym(gene)))+
        stat_boxplot(geom='errorbar',
                     width=0.2,lwd=0.2)+#添加误差棒
        geom_boxplot(mapping=aes(fill=tissue_type))+
        geom_point()+
        geom_line(aes(group = sample), color = 'gray', lwd = 0.5)+
        scale_fill_manual(values = colors)+
        theme_bw(base_size = 15)+
        labs(x="Tissue type",
             y="The expression level",
             fill="Tissue type",
             title=gene)+
        ggsignif::geom_signif(
          comparisons = list(c("Normal","Tumor")),
          map_signif_level = T,#显示型号，默认是F，也就是显示P值
          textsize = 4#显著性标记字体大小
        )+
        theme(plot.title = element_text(hjust = 0.5))
      
    },
    width = as.numeric(517),
    height = as.numeric(400))
  })
  
  output$paired_mirna_expression_download <- downloadHandler(
    filename = function() {
      paste("paired_mirna_expression_", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      
      gene <- input$paired_mirna_expression_mirna
      people <- input$paired_mirna_expression_people
      
      people_split<- strsplit(people, ":")[[1]]
      people_var <- people_split[1]
      people_filter <- people_split[2]
      
      paired_boxplot_data <- mirna %>%
        dplyr::select(id,gene) %>% 
        na.omit() %>% 
        inner_join(paired_clinical,.,by="id") %>% 
        dplyr::filter(!!sym(people_var) == people_filter)
      
      p <- ggplot(paired_boxplot_data,mapping=aes(x=tissue_type,y=!!sym(gene)))+
        stat_boxplot(geom='errorbar',
                     width=0.2,lwd=0.2)+#添加误差棒
        geom_boxplot(mapping=aes(fill=tissue_type))+
        geom_point()+
        geom_line(aes(group = sample), color = 'gray', lwd = 0.5)+
        scale_fill_manual(values = colors)+
        theme_bw(base_size = 15)+
        labs(x="Tissue type",
             y="The expression level",
             fill="Tissue type",
             title=gene)+
        ggsignif::geom_signif(
          comparisons = list(c("Normal","Tumor")),
          map_signif_level = T,#显示型号，默认是F，也就是显示P值
          textsize = 4#显著性标记字体大小
        )+
        theme(plot.title = element_text(hjust = 0.5))
      
      
      ggsave(filename = file, plot = p, 
             width = 517 / 71.5,
             height = 400 / 71.5,
             dpi = 600, units = "in")
    }
  )
  # mirna_roc
  
  observeEvent(input$mirna_roc_action,{
    
    gene <- input$mirna_roc_mirna
    
    gene_roc_data <- mirna %>% 
      dplyr::select(id,gene) %>% 
      na.omit() %>% 
      inner_join(clinical,.,by="id") %>% 
      dplyr::select(gene,tissue_type) %>% 
      mutate(tissue_type=factor(tissue_type))
    
    tsk_gene_roc_data = as_task_classif(gene_roc_data, target = "tissue_type",id="gene_roc")
    learner <- lrn("classif.log_reg",predict_type = "prob")
    learner$train(tsk_gene_roc_data)
    prediction <- learner$predict(tsk_gene_roc_data) 
    auc_score <- prediction$score(msr("classif.auc"))
    
    output$mirna_roc <- renderPlot({
      autoplot(prediction, type = "roc") +
        annotate("text", x = 0.8, y = 0.25,  # 调整文本位置
                 label = paste0("AUC = ", round(auc_score, 3)),  # 显示AUC值
                 size = 5) +  # 调整文本大小
        theme_bw(base_size = 15)+
        theme(plot.title = element_text(hjust=0.5))+
        labs(title = gene)
    },
    width = as.numeric(517),
    height = as.numeric(400))
  })
  
  output$mirna_roc_download <- downloadHandler(
    filename = function() {
      paste("mirna_roc_", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      
      gene <- input$mirna_roc_mirna
      
      gene_roc_data <- mirna %>% 
        dplyr::select(id,gene) %>% 
        na.omit() %>% 
        inner_join(clinical,.,by="id") %>% 
        dplyr::select(gene,tissue_type) %>% 
        mutate(tissue_type=factor(tissue_type))
      
      tsk_gene_roc_data = as_task_classif(gene_roc_data, target = "tissue_type",id="gene_roc")
      learner <- lrn("classif.log_reg",predict_type = "prob")
      learner$train(tsk_gene_roc_data)
      prediction <- learner$predict(tsk_gene_roc_data) 
      auc_score <- prediction$score(msr("classif.auc"))
      
      p <-  autoplot(prediction, type = "roc") +
        annotate("text", x = 0.8, y = 0.25,  # 调整文本位置
                 label = paste0("AUC = ", round(auc_score, 3)),  # 显示AUC值
                 size = 5) +  # 调整文本大小
        theme_bw(base_size = 15)+
        theme(plot.title = element_text(hjust=0.5))+
        labs(title = gene)
      
      ggsave(filename = file, plot = p, 
             width = 517 / 71.5,
             height = 400 / 71.5,
             dpi = 600, units = "in")
    }
  )
  
  # mirna_survival
  observeEvent(input$mirna_survival_action,{
    
    time <- input$mirna_survival_time
    gene <- input$mirna_survival_mirna
    people <- input$mirna_survival_people
    
    people_split <- strsplit(people, ":")[[1]]
    people_var <- people_split[1]
    people_filter <- people_split[2]
    
    # 数据处理（仅修复select警告，保留原有筛选逻辑）
    gene_survival_data <- mirna %>% 
      dplyr::select(id, gene) %>%  # 修复select外部变量警告
      na.omit() %>% 
      inner_join(clinical, ., by = "id") %>% 
      dplyr::filter(tissue_type == "Tumor") %>% 
      dplyr::filter(!!sym(people_var) == people_filter) %>%  # 保留原有筛选逻辑
      dplyr::filter(OS.time <= time) %>% 
      mutate(group = ifelse(!!sym(gene) > mean(!!sym(gene)), "High", "Low"))  # 保留原有分组逻辑
    
    fit <- ggsurvfit::survfit2(Surv(OS.time, OS) ~ group, data = gene_survival_data)
    
    output$mirna_survival <- renderPlot({
      ggsurvfit::ggsurvfit(fit)+
        ggsurvfit::add_confidence_interval()+
        ggsurvfit::add_pvalue(
          "annotation", size = 4
        ) +
        labs(x="Time(days)",
             title=gene)+
        theme_bw()+
        theme(plot.title = element_text(hjust=0.5))
    },
    width = 480,
    height = 400)
  })
  
  output$mirna_survival_download <- downloadHandler(
    filename = function() {
      paste("mirna_survival_", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      
      time <- input$mirna_survival_time
      gene <- input$mirna_survival_mirna
      people <- input$mirna_survival_people
      
      people_split <- strsplit(people, ":")[[1]]
      people_var <- people_split[1]
      people_filter <- people_split[2]
      
      # 数据处理（仅修复select警告，保留原有筛选逻辑）
      gene_survival_data <- mirna %>% 
        dplyr::select(id, gene) %>%  # 修复select外部变量警告
        na.omit() %>% 
        inner_join(clinical, ., by = "id") %>% 
        dplyr::filter(tissue_type == "Tumor") %>% 
        dplyr::filter(!!sym(people_var) == people_filter) %>%  # 保留原有筛选逻辑
        dplyr::filter(OS.time <= time) %>% 
        mutate(group = ifelse(!!sym(gene) > mean(!!sym(gene)), "High", "Low"))  # 保留原有分组逻辑
      
      fit <- ggsurvfit::survfit2(Surv(OS.time, OS) ~ group, data = gene_survival_data)
      
      p <- ggsurvfit::ggsurvfit(fit)+
        ggsurvfit::add_confidence_interval()+
        ggsurvfit::add_pvalue(
          "annotation", size = 4
        ) +
        labs(x="Time(days)",
             title=gene)+
        theme_bw()+
        theme(plot.title = element_text(hjust=0.5))
      
      ggsave(filename = file, plot = p, 
             width = 480 / 71.5,
             height = 400 / 71.5,
             dpi = 600, units = "in")
    }
  )
  
  
  # mirna_gene_prediction
  
  observeEvent(input$mirna_gene_prediction_action,{
    mir_example <- input$mirna_gene_prediction_mirna
    
    mir_result <- multiMiR::get_multimir(org = "hsa",           # 物种来源 hsa/mmu/rno                        
                             mirna = mir_example,                         
                             table = "all",   # validated/predicted/all                        
                             summary = F)  
    mir_result <- mir_result@data
    
    output$mirna_gene_prediction <- DT::renderDataTable(mir_result,
                                            options = list(
                                              scrollX = TRUE,  # 启用横向滚动
                                              pageLength = 10, # 每页显示 10 行
                                              autoWidth = TRUE))
    
  })
  
  
  
  observeEvent(input$gene_mirna_prediction_action,{
    gene_example <- input$gene_mirna_prediction_gene
    
    gene_result <- multiMiR::get_multimir(org = "hsa",                   # 物种来源 hsa/mmu/rno                        
                                          target = gene_example,               # 目标靶基因                        
                                          table = "predicted",           # 预测的miRNA-target                        
                                          summary = F,                         
                                          predicted.cutoff = 35,          # 检索范围为预测评分TOP 35%                        
                                          predicted.cutoff.type = "p",    # 检索范围为预测评分TOP 35%                        
                                          predicted.site = "all")   
    gene_result <- gene_result@data
    
    output$gene_mirna_prediction <- DT::renderDataTable(gene_result,
                                                        options = list(
                                                          scrollX = TRUE,  # 启用横向滚动
                                                          pageLength = 10, # 每页显示 10 行
                                                          autoWidth = TRUE))
    
  })
  
  
  
}