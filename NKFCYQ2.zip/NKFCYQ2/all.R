
# packages ----------------------------------------------------------------


# packages
# library(tidyverse)
library(dplyr)
library(ggplot2)
library(shiny)
library(shinydashboard)
library(shinybusy)
# library(DT)
library(mlr3)
library(mlr3viz)
library(mlr3learners)


# functions ---------------------------------------------------------------

colors2 <- ggsci::pal_ucscgb()(26)
colors1 <- ggsci::pal_simpsons("springfield")(16)
colors <- ggsci::pal_aaas("default")(10)

load("data/mirna.Rda")
mir <- colnames(mirna)[-1]
clinical_vars <- c("race:asian","race:white",
                   "gender:male","gender:female",
                   "vital_status:Alive","vital_status:Dead",
                   "stage:I","stage:II","stage:III","stage:IV",
                   "all:all",
                   "patient_age:<=60","patient_age:>60")


# header ------------------------------------------------------------------

header <- dashboardHeader(title = "NKFCYQ")


# sidebar -----------------------------------------------------------------

sidebar <- dashboardSidebar(
  sidebarMenu(
    id = "sidebar",
    menuItem("Introduction", icon = icon("database"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ1/"),
    menuItem("miRNA Analysis", icon = icon("bars"), 
             menuSubItem("miRNA-Gene Prediction", tabName = "mirna_gene_prediction"),
             menuSubItem("Gene-miRNA Prediction", tabName = "gene_mirna_prediction"),
             menuSubItem("Expression Analysis", tabName = "mirna_expression"),
             menuSubItem("Paired Expression Analysis", tabName = "paired_mirna_expression"),
             menuSubItem("Survival Analysis", tabName = "mirna_survival"),
             menuSubItem("ROC Analysis", tabName = "mirna_roc")
    ),
    menuItem("Single-gene Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ3/"),
    menuItem("Methylation Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ4/"),
    menuItem("Somatic Mutation Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ5/"),
    menuItem("Contact", icon = icon("message"), tabName = "contact"),
    menuItem("Acknowledgements", icon = icon("heart"), tabName = "Acknowledgements")
    
    
  )
)


# body --------------------------------------------------------------------

body <- dashboardBody(
  add_busy_spinner(spin = "fading-circle"),
  tabItems(
    
    # tabItem(tabName = "communications",
    #         formUI(formInfo)
    # ),
    
    # tabItem(tabName = "acknowledgements",
    #         box(width = 12,
    #             h3("学生"),
    #             hr(),
    #             h4("龚永强 南开大学医学院"),
    #             hr(),
    #             h3("指导教师"),
    #             hr(),
    #             h4("刘寅教授 南开大学医学院")
    #         ))
    
    # mirna_expression
    tabItem(tabName = "mirna_expression",
            fluidRow(
              box(width=3,
                  
                  column(12,
                         selectInput(
                           "mirna_expression_people", 
                           label = "People", 
                           choices = clinical_vars,  # 直接使用向量
                           selected = clinical_vars[3]  # 默认选中第一个元素
                         )),
                  
                  
                  column(12,
                         selectInput(
                           "mirna_expression_mirna", 
                           label = "miRNA", 
                           choices = mir,  # 直接使用向量
                           selected = mir[1]  # 默认选中第一个元素
                         )),
                  
                  column(6,
                         actionButton("mirna_expression_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                  #                    max = 400, value = 300)
                  # )
              ),
              
              box(width = 9,
                  downloadButton("mirna_expression_download", "Download"),
                  hr(),
                  plotOutput("mirna_expression")
              )
              
            )),
    
    # paired_mirna_expression
    
    tabItem(tabName = "paired_mirna_expression",
            fluidRow(
              box(width=3,
                  
                  column(12,
                         selectInput(
                           "paired_mirna_expression_people", 
                           label = "People", 
                           choices = clinical_vars,  # 直接使用向量
                           selected = clinical_vars[3]  # 默认选中第一个元素
                         )),
                  
                  
                  column(12,
                         selectInput(
                           "paired_mirna_expression_mirna", 
                           label = "miRNA", 
                           choices = mir,  # 直接使用向量
                           selected = mir[1]  # 默认选中第一个元素
                         )),
                  
                  column(6,
                         actionButton("paired_mirna_expression_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                  #                    max = 400, value = 300)
                  # )
              ),
              
              box(width = 9,
                  downloadButton("paired_mirna_expression_download", "Download"),
                  hr(),
                  plotOutput("paired_mirna_expression")
              )
              
            )),
    
    
    # mirna_roc
    
    tabItem(tabName = "mirna_roc",
            fluidRow(
              box(width=3,
                  
                  column(12,
                         selectInput(
                           "mirna_roc_mirna", 
                           label = "miRNA", 
                           choices = mir,  # 直接使用向量
                           selected = mir[1]  # 默认选中第一个元素
                         )),
                  
                  column(6,
                         actionButton("mirna_roc_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                  #                    max = 400, value = 300)
                  # )
              ),
              
              box(width = 9,
                  downloadButton("mirna_roc_download", "Download"),
                  hr(),
                  plotOutput("mirna_roc")
              )
              
            )),
    
    
    tabItem(tabName = "mirna_survival",
            fluidRow(
              box(width=3,
                  
                  column(12,
                         selectInput(
                           "mirna_survival_people", 
                           label = "People", 
                           choices = clinical_vars,  # 直接使用向量
                           selected = clinical_vars[3]  # 默认选中第一个元素
                         )),
                  
                  column(12,
                         selectInput(
                           "mirna_survival_mirna", 
                           label = "miRNA", 
                           choices = mir,  # 直接使用向量
                           selected = mir[1]  # 默认选中第一个元素
                         )),
                  
                  column(12,
                         selectInput(
                           "mirna_survival_time", 
                           label = "Time", 
                           choices = list("1 year" = 365, "3 year" = 1095, "5 year" = 1825,"10 year" = 3650), 
                           selected = 3650  # 默认选中第一个元素
                         )),
                  
                  column(6,
                         actionButton("mirna_survival_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_survival_width", label = "Width", min = 0,
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_survival_height", label = "Height", min = 0,
                  #                    max = 500, value = 300)
                  # )
              ),
              
              box(width = 9,
                  # height = 600,
                  downloadButton("mirna_survival_download", "Download"),
                  hr(),
                  plotOutput("mirna_survival")
              )
              
            )),
    
    
    
    tabItem(tabName = "mirna_gene_prediction",
            fluidRow(
              box(width=3,
                  
                  column(12,
                         textInput("mirna_gene_prediction_mirna",
                                   label = "miRNA",
                                   value = mir[100])),
                  
                  column(6,
                         actionButton("mirna_gene_prediction_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_survival_width", label = "Width", min = 0,
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_survival_height", label = "Height", min = 0,
                  #                    max = 500, value = 300)
                  # )
              ),
              
              box(width = 9,
                  DT::dataTableOutput("mirna_gene_prediction")
              )
              
            )),
    
    
    
    
    tabItem(tabName = "gene_mirna_prediction",
            fluidRow(
              box(width=3,
                  
                  column(12,
                         textInput("gene_mirna_prediction_gene",
                                   label = "Gene",
                                   value = "TP53")),
                  
                  column(6,
                         actionButton("gene_mirna_prediction_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_survival_width", label = "Width", min = 0,
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_survival_height", label = "Height", min = 0,
                  #                    max = 500, value = 300)
                  # )
              ),
              
              box(width = 9,
                  DT::dataTableOutput("gene_mirna_prediction")
              )
              
            )),
    # contact
    tabItem(tabName = "contact",
            fluidRow(
              box(width = 12,
                  div(class = "intro-content",
                      h2("Contact Us"),
                      p("If you encounter any problems while using NKFCYQ, or have suggestions for improving the platform, please feel free to contact us through the following methods. We will respond to your inquiries as soon as possible."),
                      
                      div(class = "contact-method",
                          p(strong("Email:"), "gongyq@mail.nankai.edu.cn")  # 可替换为实际邮箱地址
                      ),
                      
                      div(class = "contact-method",
                          p(strong("WeChat:"), "gongyqnankai")  # 可替换为实际微信号
                      )
                  )
              )
            )),
    
    tabItem(tabName = "Acknowledgements",
            fluidRow(
              box(width = 12,
                  div(class = "intro-content",
                      h2("Acknowledgements"),
                      p("We would like to express our sincere gratitude to all individuals and organizations who have contributed to the development of NKFCYQ."),
                      
                  )
              )
            ))
    
    
    
    
  )
)


# server ------------------------------------------------------------------

# server ------------------------------------------------------------------

server <- function(input, output, session) {
  
  # 验证密码
  # res_auth <- secure_server(
  #   check_credentials = check_credentials(credentials)
  # )
  
  # communications
  # formServer(formInfo)
  
  
  # gene_expression
  observeEvent(input$mirna_expression_action,{
    
    gene <- input$mirna_expression_mirna
    people <- input$mirna_expression_people
    
    people_split<- strsplit(people, ":")[[1]]
    people_var <- people_split[1]
    people_filter <- people_split[2]
    
    boxplot_data <- mirna %>%
      dplyr::select(id,gene) %>% 
      na.omit() %>% 
      inner_join(clinical,.,by="id") %>% 
      dplyr::filter(!!sym(people_var) == people_filter)
    
    output$mirna_expression <- renderPlot({
      ggplot(boxplot_data,mapping=aes(x=tissue_type,y=!!sym(gene)))+
        stat_boxplot(geom='errorbar',
                     width=0.2,lwd=0.2)+#添加误差棒
        geom_boxplot(mapping=aes(fill=tissue_type))+
        scale_fill_manual(values = colors)+
        theme_bw(base_size = 15)+
        labs(x="Tissue type",
             y="The expression level",
             fill="Tissue type",
             title=gene)+
        ggsignif::geom_signif(
          comparisons = list(c("Normal","Tumor")),
          map_signif_level = T,#显示型号，默认是F，也就是显示P值
          textsize = 4#显著性标记字体大小
        )+
        theme(plot.title = element_text(hjust = 0.5))
      
    },
    width = as.numeric(517),
    height = as.numeric(400))
  })
  
  output$mirna_expression_download <- downloadHandler(
    filename = function() {
      paste("mirna_expression_", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      
      gene <- input$mirna_expression_mirna
      people <- input$mirna_expression_people
      
      people_split<- strsplit(people, ":")[[1]]
      people_var <- people_split[1]
      people_filter <- people_split[2]
      
      boxplot_data <- mirna %>%
        dplyr::select(id,gene) %>% 
        na.omit() %>% 
        inner_join(clinical,.,by="id") %>% 
        dplyr::filter(!!sym(people_var) == people_filter)
      
      p <- ggplot(boxplot_data,mapping=aes(x=tissue_type,y=!!sym(gene)))+
        stat_boxplot(geom='errorbar',
                     width=0.2,lwd=0.2)+#添加误差棒
        geom_boxplot(mapping=aes(fill=tissue_type))+
        scale_fill_manual(values = colors)+
        theme_bw(base_size = 15)+
        labs(x="Tissue type",
             y="The expression level",
             fill="Tissue type",
             title=gene)+
        ggsignif::geom_signif(
          comparisons = list(c("Normal","Tumor")),
          map_signif_level = T,#显示型号，默认是F，也就是显示P值
          textsize = 4#显著性标记字体大小
        )+
        theme(plot.title = element_text(hjust = 0.5))
      
      ggsave(filename = file, plot = p, 
             width = 517 / 71.5,
             height = 400 / 71.5,
             dpi = 600, units = "in")
    }
  )
  # paired_mirna_expression
  
  observeEvent(input$paired_mirna_expression_action,{
    
    gene <- input$paired_mirna_expression_mirna
    people <- input$paired_mirna_expression_people
    
    people_split<- strsplit(people, ":")[[1]]
    people_var <- people_split[1]
    people_filter <- people_split[2]
    
    paired_boxplot_data <- mirna %>%
      dplyr::select(id,gene) %>% 
      na.omit() %>% 
      inner_join(paired_clinical,.,by="id") %>% 
      dplyr::filter(!!sym(people_var) == people_filter)
    
    output$paired_mirna_expression <- renderPlot({
      ggplot(paired_boxplot_data,mapping=aes(x=tissue_type,y=!!sym(gene)))+
        stat_boxplot(geom='errorbar',
                     width=0.2,lwd=0.2)+#添加误差棒
        geom_boxplot(mapping=aes(fill=tissue_type))+
        geom_point()+
        geom_line(aes(group = sample), color = 'gray', lwd = 0.5)+
        scale_fill_manual(values = colors)+
        theme_bw(base_size = 15)+
        labs(x="Tissue type",
             y="The expression level",
             fill="Tissue type",
             title=gene)+
        ggsignif::geom_signif(
          comparisons = list(c("Normal","Tumor")),
          map_signif_level = T,#显示型号，默认是F，也就是显示P值
          textsize = 4#显著性标记字体大小
        )+
        theme(plot.title = element_text(hjust = 0.5))
      
    },
    width = as.numeric(517),
    height = as.numeric(400))
  })
  
  output$paired_mirna_expression_download <- downloadHandler(
    filename = function() {
      paste("paired_mirna_expression_", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      
      gene <- input$paired_mirna_expression_mirna
      people <- input$paired_mirna_expression_people
      
      people_split<- strsplit(people, ":")[[1]]
      people_var <- people_split[1]
      people_filter <- people_split[2]
      
      paired_boxplot_data <- mirna %>%
        dplyr::select(id,gene) %>% 
        na.omit() %>% 
        inner_join(paired_clinical,.,by="id") %>% 
        dplyr::filter(!!sym(people_var) == people_filter)
      
      p <- ggplot(paired_boxplot_data,mapping=aes(x=tissue_type,y=!!sym(gene)))+
        stat_boxplot(geom='errorbar',
                     width=0.2,lwd=0.2)+#添加误差棒
        geom_boxplot(mapping=aes(fill=tissue_type))+
        geom_point()+
        geom_line(aes(group = sample), color = 'gray', lwd = 0.5)+
        scale_fill_manual(values = colors)+
        theme_bw(base_size = 15)+
        labs(x="Tissue type",
             y="The expression level",
             fill="Tissue type",
             title=gene)+
        ggsignif::geom_signif(
          comparisons = list(c("Normal","Tumor")),
          map_signif_level = T,#显示型号，默认是F，也就是显示P值
          textsize = 4#显著性标记字体大小
        )+
        theme(plot.title = element_text(hjust = 0.5))
      
      
      ggsave(filename = file, plot = p, 
             width = 517 / 71.5,
             height = 400 / 71.5,
             dpi = 600, units = "in")
    }
  )
  # mirna_roc
  
  observeEvent(input$mirna_roc_action,{
    
    gene <- input$mirna_roc_mirna
    
    gene_roc_data <- mirna %>% 
      dplyr::select(id,gene) %>% 
      na.omit() %>% 
      inner_join(clinical,.,by="id") %>% 
      dplyr::select(gene,tissue_type) %>% 
      mutate(tissue_type=factor(tissue_type))
    
    tsk_gene_roc_data = as_task_classif(gene_roc_data, target = "tissue_type",id="gene_roc")
    learner <- lrn("classif.log_reg",predict_type = "prob")
    learner$train(tsk_gene_roc_data)
    prediction <- learner$predict(tsk_gene_roc_data) 
    auc_score <- prediction$score(msr("classif.auc"))
    
    output$mirna_roc <- renderPlot({
      autoplot(prediction, type = "roc") +
        annotate("text", x = 0.8, y = 0.25,  # 调整文本位置
                 label = paste0("AUC = ", round(auc_score, 3)),  # 显示AUC值
                 size = 5) +  # 调整文本大小
        theme_bw(base_size = 15)+
        theme(plot.title = element_text(hjust=0.5))+
        labs(title = gene)
    },
    width = as.numeric(517),
    height = as.numeric(400))
  })
  
  output$mirna_roc_download <- downloadHandler(
    filename = function() {
      paste("mirna_roc_", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      
      gene <- input$mirna_roc_mirna
      
      gene_roc_data <- mirna %>% 
        dplyr::select(id,gene) %>% 
        na.omit() %>% 
        inner_join(clinical,.,by="id") %>% 
        dplyr::select(gene,tissue_type) %>% 
        mutate(tissue_type=factor(tissue_type))
      
      tsk_gene_roc_data = as_task_classif(gene_roc_data, target = "tissue_type",id="gene_roc")
      learner <- lrn("classif.log_reg",predict_type = "prob")
      learner$train(tsk_gene_roc_data)
      prediction <- learner$predict(tsk_gene_roc_data) 
      auc_score <- prediction$score(msr("classif.auc"))
      
      p <-  autoplot(prediction, type = "roc") +
        annotate("text", x = 0.8, y = 0.25,  # 调整文本位置
                 label = paste0("AUC = ", round(auc_score, 3)),  # 显示AUC值
                 size = 5) +  # 调整文本大小
        theme_bw(base_size = 15)+
        theme(plot.title = element_text(hjust=0.5))+
        labs(title = gene)
      
      ggsave(filename = file, plot = p, 
             width = 517 / 71.5,
             height = 400 / 71.5,
             dpi = 600, units = "in")
    }
  )
  
  # mirna_survival
  observeEvent(input$mirna_survival_action,{
    
    time <- input$mirna_survival_time
    gene <- input$mirna_survival_mirna
    people <- input$mirna_survival_people
    
    people_split <- strsplit(people, ":")[[1]]
    people_var <- people_split[1]
    people_filter <- people_split[2]
    
    # 数据处理（仅修复select警告，保留原有筛选逻辑）
    gene_survival_data <- mirna %>% 
      dplyr::select(id, gene) %>%  # 修复select外部变量警告
      na.omit() %>% 
      inner_join(clinical, ., by = "id") %>% 
      dplyr::filter(tissue_type == "Tumor") %>% 
      dplyr::filter(!!sym(people_var) == people_filter) %>%  # 保留原有筛选逻辑
      dplyr::filter(OS.time <= time) %>% 
      mutate(group = ifelse(!!sym(gene) > mean(!!sym(gene)), "High", "Low"))  # 保留原有分组逻辑
    
    fit <- ggsurvfit::survfit2(Surv(OS.time, OS) ~ group, data = gene_survival_data)
    
    output$mirna_survival <- renderPlot({
      ggsurvfit::ggsurvfit(fit)+
        ggsurvfit::add_confidence_interval()+
        ggsurvfit::add_pvalue(
          "annotation", size = 4
        ) +
        labs(x="Time(days)",
             title=gene)+
        theme_bw()+
        theme(plot.title = element_text(hjust=0.5))
    },
    width = 480,
    height = 400)
  })
  
  output$mirna_survival_download <- downloadHandler(
    filename = function() {
      paste("mirna_survival_", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      
      time <- input$mirna_survival_time
      gene <- input$mirna_survival_mirna
      people <- input$mirna_survival_people
      
      people_split <- strsplit(people, ":")[[1]]
      people_var <- people_split[1]
      people_filter <- people_split[2]
      
      # 数据处理（仅修复select警告，保留原有筛选逻辑）
      gene_survival_data <- mirna %>% 
        dplyr::select(id, gene) %>%  # 修复select外部变量警告
        na.omit() %>% 
        inner_join(clinical, ., by = "id") %>% 
        dplyr::filter(tissue_type == "Tumor") %>% 
        dplyr::filter(!!sym(people_var) == people_filter) %>%  # 保留原有筛选逻辑
        dplyr::filter(OS.time <= time) %>% 
        mutate(group = ifelse(!!sym(gene) > mean(!!sym(gene)), "High", "Low"))  # 保留原有分组逻辑
      
      fit <- ggsurvfit::survfit2(Surv(OS.time, OS) ~ group, data = gene_survival_data)
      
      p <- ggsurvfit::ggsurvfit(fit)+
        ggsurvfit::add_confidence_interval()+
        ggsurvfit::add_pvalue(
          "annotation", size = 4
        ) +
        labs(x="Time(days)",
             title=gene)+
        theme_bw()+
        theme(plot.title = element_text(hjust=0.5))
      
      ggsave(filename = file, plot = p, 
             width = 480 / 71.5,
             height = 400 / 71.5,
             dpi = 600, units = "in")
    }
  )
  
  
  # mirna_gene_prediction
  
  observeEvent(input$mirna_gene_prediction_action,{
    mir_example <- input$mirna_gene_prediction_mirna
    
    mir_result <- multiMiR::get_multimir(org = "hsa",           # 物种来源 hsa/mmu/rno                        
                                         mirna = mir_example,                         
                                         table = "all",   # validated/predicted/all                        
                                         summary = F)  
    mir_result <- mir_result@data
    
    output$mirna_gene_prediction <- DT::renderDataTable(mir_result,
                                                        options = list(
                                                          scrollX = TRUE,  # 启用横向滚动
                                                          pageLength = 10, # 每页显示 10 行
                                                          autoWidth = TRUE))
    
  })
  
  
  
  observeEvent(input$gene_mirna_prediction_action,{
    gene_example <- input$gene_mirna_prediction_gene
    
    gene_result <- multiMiR::get_multimir(org = "hsa",                   # 物种来源 hsa/mmu/rno                        
                                          target = gene_example,               # 目标靶基因                        
                                          table = "predicted",           # 预测的miRNA-target                        
                                          summary = F,                         
                                          predicted.cutoff = 35,          # 检索范围为预测评分TOP 35%                        
                                          predicted.cutoff.type = "p",    # 检索范围为预测评分TOP 35%                        
                                          predicted.site = "all")   
    gene_result <- gene_result@data
    
    output$gene_mirna_prediction <- DT::renderDataTable(gene_result,
                                                        options = list(
                                                          scrollX = TRUE,  # 启用横向滚动
                                                          pageLength = 10, # 每页显示 10 行
                                                          autoWidth = TRUE))
    
  })
  
  
  
}


# app ---------------------------------------------------------------------


ui <- dashboardPage(
  # dashboardHeader(title = "Tianjin First Central Hospital"),
  header, sidebar, body)

# ui <- secure_app(ui)
# options(shiny.maxRequestSize = 60 * 1024^2)

shinyApp(ui, server)
