library(tidyverse)
library(data.table)
colors2 <- ggsci::pal_ucscgb()(26)
colors1 <- ggsci::pal_simpsons("springfield")(16)
colors <- ggsci::pal_aaas("default")(10)

# 1 miRNA data ------------------------------------------------------------

mirna <- fread("/home/yqgong/shiny/NKFCYQSG/TCGA_LIHC/TCGA-LIHC.mirna.tsv")
load("~/shiny/NKFCYQSG/data/clinical.Rda")

# 剔除表达量在多数样本为0
zero_ratio <- rowMeans(mirna [, -1] == 0)
filtered_expr <- mirna[zero_ratio <= 0.5, ]

# 基因名字重复取平均值
mirna <- filtered_expr %>% 
  aggregate(.~miRNA_ID,.,mean) %>% 
  column_to_rownames(var = "miRNA_ID") %>% 
  t() %>% 
  as.data.frame() %>% 
  rownames_to_column(var = "id") %>% 
  filter(id %in% clinical$id)

clinical <- clinical %>% 
  filter(id %in% mirna$id)

save(mirna,clinical,
     file = "mirna.Rda")

# 2 expression -----------------------------------------------------------------

mir <- colnames(mirna)[-1]
gene <- "hsa-mir-98"
people <- "patient_age:<=60"

people_split<- strsplit(people, ":")[[1]]
people_var <- people_split[1]
people_filter <- people_split[2]

boxplot_data <- mirna %>%
  dplyr::select(id,gene) %>% 
  inner_join(clinical,.,by="id") %>% 
  dplyr::filter(!!sym(people_var) == people_filter)

ggplot(boxplot_data,mapping=aes(x=tissue_type,y=!!sym(gene)))+
  stat_boxplot(geom='errorbar',
               width=0.2,lwd=0.2)+#添加误差棒
  geom_boxplot(mapping=aes(fill=tissue_type))+
  scale_fill_manual(values = colors)+
  theme_bw(base_size = 15)+
  labs(x="Tissue type",
       y=str_c("The expression level"),
       title=gene,
       fill="Tissue type")+
  ggsignif::geom_signif(
    comparisons = list(c("Normal","Tumor")),
    map_signif_level = T,#显示型号，默认是F，也就是显示P值
    textsize = 4#显著性标记字体大小
  )+
  theme(plot.title = element_text(hjust = 0.5))


# 3 survival  -------------------------------------------------------------

gene <- "hsa-mir-98"
time <- 1095
people <- "all:all"

people_split<- strsplit(people, ":")[[1]]
people_var <- people_split[1]
people_filter <- people_split[2]

gene_survival_data <- mirna %>% 
  dplyr::select(id,gene) %>% 
  na.omit() %>% 
  inner_join(clinical,.,by="id") %>% 
  dplyr::filter(tissue_type=="Tumor") %>% 
  dplyr::filter(!!sym(people_var) == people_filter) %>% 
  dplyr::filter(OS.time <= time) %>% 
  mutate(group=ifelse(!!sym(gene)>mean(!!sym(gene)),"High","Low"))

fit <- ggsurvfit::survfit2(Surv(OS.time, OS) ~ group, data = gene_survival_data)
ggsurvfit::ggsurvfit(fit)+
  ggsurvfit::add_confidence_interval()+
  ggsurvfit::add_pvalue(
    "annotation", size = 4
  ) +
  theme_bw()+
  labs(x="Time(days)",
       title=gene)+
  theme(plot.title = element_text(hjust=0.5))


# 4 paired expression -----------------------------------------------------

paired_clinical <- clinical %>% 
  group_by(sample) %>% 
  dplyr::filter(n()==2) %>% 
  ungroup()

save(clinical,mirna,paired_clinical,
     file = "mirna.Rda")

gene <- "hsa-mir-98"
people <- "patient_age:<=60"

people_split<- strsplit(people, ":")[[1]]
people_var <- people_split[1]
people_filter <- people_split[2]

paired_boxplot_data <- mirna %>%
  dplyr::select(id,gene) %>% 
  na.omit() %>% 
  inner_join(paired_clinical,.,by="id") %>% 
  dplyr::filter(!!sym(people_var) == people_filter)

ggplot(paired_boxplot_data,mapping=aes(x=tissue_type,y=!!sym(gene)))+
  stat_boxplot(geom='errorbar',
               width=0.2,lwd=0.2)+#添加误差棒
  geom_boxplot(mapping=aes(fill=tissue_type))+
  geom_point()+
  geom_line(aes(group = sample), color = 'gray', lwd = 0.5)+
  scale_fill_manual(values = colors)+
  theme_bw(base_size = 15)+
  labs(x="Tissue type",
       y=str_c("The expression level of ",gene),
       fill="Tissue type")+
  ggsignif::geom_signif(
    comparisons = list(c("Normal","Tumor")),
    map_signif_level = T,#显示型号，默认是F，也就是显示P值
    textsize = 4#显著性标记字体大小
  )+
  theme(plot.title = element_text(hjust = 0.5))


# 5 roc -------------------------------------------------------------------

library(mlr3)
library(mlr3viz)
library(mlr3verse)
library(mlr3learners)

gene <- mir[89]

gene_roc_data <- mirna %>% 
  dplyr::select(id,gene) %>% 
  na.omit() %>% 
  inner_join(clinical,.,by="id") %>% 
  dplyr::select(gene,tissue_type) %>% 
  mutate(tissue_type=factor(tissue_type))

tsk_gene_roc_data = as_task_classif(gene_roc_data, target = "tissue_type",id="gene_roc")
learner <- lrn("classif.log_reg",predict_type = "prob")
learner$train(tsk_gene_roc_data)
prediction <- learner$predict(tsk_gene_roc_data) 
auc_score <- prediction$score(msr("classif.auc"))
autoplot(prediction, type = "roc") +
  annotate("text", x = 0.8, y = 0.25,  # 调整文本位置
           label = paste0("AUC = ", round(auc_score, 3)),  # 显示AUC值
           size = 5) +  # 调整文本大小
  theme_bw(base_size = 15)+
  theme(plot.title = element_text(hjust=0.5))+
  labs(title = gene)


# 6. mir-gene -------------------------------------------------------------

library(multiMiR)
mir_example <- mir[100]

example1 <- get_multimir(org = "hsa",           # 物种来源 hsa/mmu/rno                        
                         mirna = mir_example,                         
                         table = "all",   # validated/predicted/all                        
                         summary = F)  
example1_result <- example1@data    

example2 <- get_multimir(org = "hsa",                   # 物种来源 hsa/mmu/rno                        
                         target = "TP53",               # 目标靶基因                        
                         table = "predicted",           # 预测的miRNA-target                        
                         summary = F,                         
                         predicted.cutoff = 35,          # 检索范围为预测评分TOP 35%                        
                         predicted.cutoff.type = "p",    # 检索范围为预测评分TOP 35%                        
                         predicted.site = "all")        
example2_result <- example2@data

