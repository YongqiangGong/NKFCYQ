colors2 <- ggsci::pal_ucscgb()(26)
colors1 <- ggsci::pal_simpsons("springfield")(16)
colors <- ggsci::pal_aaas("default")(10)

load("data/mirna.Rda")
mir <- colnames(mirna)[-1]
clinical_vars <- c("race:asian","race:white",
                   "gender:male","gender:female",
                   "vital_status:Alive","vital_status:Dead",
                   "stage:I","stage:II","stage:III","stage:IV",
                   "all:all",
                   "patient_age:<=60","patient_age:>60")