sidebar <- dashboardSidebar(
  sidebarMenu(
    id = "sidebar",
    menuItem("Introduction", icon = icon("database"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ/"),
    menuItem("miRNA Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ1/"),
    menuItem("Single-gene Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ2/"),
    menuItem("Methylation Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ3/"),
    menuItem("Somatic Mutation Analysis",
            icon = icon("bars"),
            menuSubItem("Summary", tabName = "somatic_mutation_summary"),
            menuSubItem("Mutation Site", tabName = "somatic_mutation_site"),
            menuSubItem("Survival Analysis", tabName = "somatic_mutation_survival"),
            menuSubItem("Drug-Gene Interactions", tabName = "somatic_mutation_drug")
      ),
    menuItem("Contact", icon = icon("message"), tabName = "contact"),
    menuItem("Acknowledgements", icon = icon("heart"), tabName = "Acknowledgements")
    
    
))