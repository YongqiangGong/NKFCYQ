# 1 packages --------------------------------------------------------------

library(tidyverse)
library(data.table)

# 2 Somatic Mutation Analysis -----------------------------------------------

maf <- TCGAmutations::tcga_load(study = "LIHC")
clinical <- clinical %>% 
  dplyr::select(id,OS.time,OS,vital_status)
# 提取了每个样本的名称(前者是1：16位的/后者是全称)
samp=data.frame(id=str_sub(unique(maf@data$Tumor_Sample_Barcode),1,16),
                Tumor_Sample_Barcode=unique(maf@data$Tumor_Sample_Barcode))
#merge()函数会自动根据指定的列（如ID列）将两个数据框的数据进行配对合并
samp=merge(clinical,samp,by="id")
#临床信息
#其实上面已经准备好了，再来一次吧~
maf@clinical.data=samp
maf@clinical.data=inner_join(maf@clinical.data,samp,by="Tumor_Sample_Barcode")
# subsetMaf()是maftools包中的一个函数，用于从原始MAF 数据中提取特定的样本或突变类型的子集。
maf=maftools::subsetMaf(maf,tsb=samp$Tumor_Sample_Barcode)

#定义突变参数
cla1=c('Frame_Shift_Del','Missense_Mutation',
       # 'Nonsense_Mutation','Multi_Hit','Frame_Shift_Ins',
       'In_Frame_Ins','Splice_Site','In_Frame_Del')
#上面的信息藏在variant.classification.summary中
cla2=colnames(maf@variant.classification.summary)[-c(1,ncol(maf@variant.classification.summary))]
#使用intersect函数找到cla1和cla2的交集，即共同的突变分类；然后使用setdiff函数找到cla2中不在cla1中的突变分类，将它们合并以形成最终的突变分类列表cla
cla=c(intersect(cla1,cla2),setdiff(cla2,cla1))
#突变分类分配颜色
col=RColorBrewer::brewer.pal(n=length(cla),name='Paired')
names(col)=cla

racecolor=colors1[1:4];names(racecolor)=na.omit(unique(maf@clinical.data$race))
stagecolor=colors1[5:8];names(stagecolor)=na.omit(unique(maf@clinical.data$stage))
agecolor=colors1[9:10];names(agecolor)=na.omit(unique(maf@clinical.data$patient_age))
gendercolor=colors1[11:12];names(gendercolor)=na.omit(unique(maf@clinical.data$gender))

fabcolors=list(race=racecolor,
               stage=stagecolor,
               patient_age=agecolor,
               gender=gendercolor)

# oncoplot

png("oncoplot.png", width = 1500, height = 1500, res = 300)
maftools::oncoplot(
  maf = maf,
  colors = colors,
  top = 20
)
dev.off()

png("mafSummary.png", width = 2500, height = 1500, res = 300)
maftools::plotmafSummary(maf=maf,
                         rmOutlier=TRUE,
                         addStat="median",
                         dashboard=TRUE,
                         titvRaw=FALSE)
dev.off()

png("titv.png", width = 1000, height = 1000, res = 300)
titv<-maftools::titv(maf=maf,
                     plot=F,
                     useSyn=TRUE)
maftools::plotTiTv(res=titv)
dev.off()

png("rainfall.png", width = 2000, height = 2000, res = 300)
maftools::rainfallPlot(maf=maf,
                       tsb=NULL,#修改这里可以看特定样本
                       detectChangePoints=TRUE,
                       pointSize=0.4)
dev.off()

png("Vaf.png", width = 2000, height = 2000, res = 300)
maftools::plotVaf(maf=maf,
                  top=20)
dev.off()

png("lollipopPlot.png", width = 2000, height = 2000, res = 300)
maftools::lollipopPlot(maf=maf,
                       gene="RASAL2",
                       # AACol="HGVSp_Short",
                       showMutationRate=TRUE)
dev.off()

dat <- maftools::somaticInteractions(maf = maf, top = 30, pvalue = c(0.05, 0.1)) %>% 
  as.data.frame() %>% 
  dplyr::filter(pValue <=0.05)
dat

maf@clinical.data$OS.time<-as.numeric(maf@clinical.data$OS.time)
maftools::mafSurvival(maf=maf,
            genes=c('TP53'),
            time='OS.time',
            Status='OS')

#计算获得能够获得生存显著性及基因集合
prog_geneset=maftools::survGroup(maf=maf,
                       top=100,#应用突变频率前20的基因集作为母集
                       geneSetSize=1,#每2个基因作为signature计算的依据
                       time="OS.time",
                       Status="OS",
                       verbose=FALSE)
prog_geneset

# 指定基因进行分析
maftools::mafSurvGroup(maf=maf,
             geneSet=c("DOCK2"),
             time="OS.time",
             Status="OS")

race=clinicalEnrichment(maf=maf,
                        clinicalFeature='race.y')

OS=clinicalEnrichment(maf=maf,
                      clinicalFeature='OS')
#查看有统计学意义的突变类型
race$groupwise_comparision[p_value<0.05]
#对有意义的临床表型-突变组合数据进行可视化
plotEnrichmentResults(enrich_res=race,
                      pVal=0.05,
                      geneFontSize=0.5,
                      annoFontSize=0.6)

plotEnrichmentResults(enrich_res=OS,
                      pVal=0.05,
                      geneFontSize=0.5,
                      annoFontSize=0.6)

#查看药物-突变相关作用(潜在可靶药物)作用
drug=maftools::drugInteractions(maf=maf,fontSize=0.75)

#查看数据库中特定基因的可靶药物
drug_gene=maftools::drugInteractions(genes="TP53",drugs=TRUE) %>% 
  as.data.frame()


maf@clinical.data

fab.ce = maftools::clinicalEnrichment(maf = maf, clinicalFeature = 'vital_status')
fab.ce$groupwise_comparision[p_value < 0.05]
plotEnrichmentResults(enrich_res = fab.ce, pVal = 0.05, geneFontSize = 0.5, annoFontSize = 0.6)

png("oncoplot.png", width = 2000, height = 2000, res = 300)
maftools::plotmafSummary(maf = maf, rmOutlier = TRUE, addStat = 'median', dashboard = TRUE, titvRaw = FALSE)
dev.off()
png("oncoplot.png", width = 2000, height = 2000, res = 300)
maftools::oncoplot(maf, top = 20)
dev.off()
png("plotTiTv.png", width = 2000, height = 2000, res = 300)
laml.titv <- maftools::titv(maf, plot = T, useSyn = TRUE)
maftools::plotTiTv(res = laml.titv)
dev.off()
png("plotTiTv.png", width = 2000, height = 2000, res = 300)
maftools::rainfallPlot(maf = maf, detectChangePoints = TRUE, pointSize = 0.4)
dev.off()
