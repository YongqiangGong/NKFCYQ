# packages
# library(tidyverse)
library(dplyr)
library(ggplot2)
library(shiny)
library(shinydashboard)
library(shinybusy)

source("functions.R")
source("header.R")
source("sidebar.R")
source("body.R") 
source("server.R")

# app ---------------------------------------------------------------------

ui <- dashboardPage(
  # dashboardHeader(title = "Tianjin First Central Hospital"),
  header, sidebar, body)

# ui <- secure_app(ui)
# options(shiny.maxRequestSize = 60 * 1024^2)

shinyApp(ui, server)

