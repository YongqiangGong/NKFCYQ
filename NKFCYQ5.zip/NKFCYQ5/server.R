# server ------------------------------------------------------------------

server <- function(input, output, session) {
  
  # 验证密码
  # res_auth <- secure_server(
  #   check_credentials = check_credentials(credentials)
  # )
  
  
  # summary
  
  output$plotmafSummary <- renderPlot({
    maftools::plotmafSummary(maf = maf, 
                             rmOutlier = TRUE, 
                             addStat = 'median', 
                             dashboard = TRUE, 
                             titvRaw = FALSE)
  }
  )
  
  output$plotmafSummary_download <- downloadHandler(
    filename = function() {
      paste("mafSummary__", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      png(file, width = 2000, height = 2000, res = 300)
      maftools::plotmafSummary(maf = maf, 
                               rmOutlier = TRUE, 
                               addStat = 'median', 
                               dashboard = TRUE, 
                               titvRaw = FALSE)
      dev.off()
      
    }
  )
  
  
  
  output$oncoplot <- renderPlot({
    maftools::oncoplot(maf, top = 20)
  }
  )
  
  output$oncoplot_download <- downloadHandler(
    filename = function() {
      paste("oncoplot__", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      png(file, width = 2000, height = 2000, res = 300)
      maftools::oncoplot(maf, top = 20)
      dev.off()
      
    }
  )
  
  
  output$plotTiTv<- renderPlot({
    laml.titv <- maftools::titv(maf, plot = F, useSyn = TRUE)
    maftools::plotTiTv(res = laml.titv)
  }
  )
  
  output$plotTiTv_download <- downloadHandler(
    filename = function() {
      paste("TiTv__", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      png(file, width = 2000, height = 2000, res = 300)
      laml.titv <- maftools::titv(maf, plot = F, useSyn = TRUE)
      maftools::plotTiTv(res = laml.titv)
      dev.off()
      
    }
  )
  
  
  
  output$rainfallPlot<- renderPlot({
    maftools::rainfallPlot(maf = maf, detectChangePoints = TRUE, pointSize = 0.4)
  }
  )
  
  output$rainfallPlot_download <- downloadHandler(
    filename = function() {
      paste("rainfallPlot__", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      png(file, width = 2000, height = 2000, res = 300)
      maftools::rainfallPlot(maf = maf, detectChangePoints = TRUE, pointSize = 0.4)
      dev.off()
      
    }
  )
  
  # somatic_mutation_site
  observeEvent(input$somatic_mutation_site_action,{
    
    site_gene <- input$somatic_mutation_site_gene
    
    output$somatic_mutation_site <- renderPlot({
      maftools::lollipopPlot(maf=maf,
                             gene=site_gene,
                             # AACol="HGVSp_Short",
                             showMutationRate=TRUE)
    },
    width = as.numeric(600),
    height = as.numeric(120))
  })
  
  output$somatic_mutation_site_download <- downloadHandler(
    filename = function() {
      paste("somatic_mutation_site_", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      png(file, width = 20000, height = 4000, res = 600)
      maftools::lollipopPlot(maf=maf,
                             gene=input$somatic_mutation_site_gene,
                             # AACol="HGVSp_Short",
                             showMutationRate=TRUE)
      dev.off()
      
    }
  )
  
  
  
  # somatic_interactions
  observeEvent(input$somatic_mutation_interactions_action,{
    
    somatic_mutation_interactions_data <- maftools::somaticInteractions(maf = maf, top = input$somatic_mutation_interactions_genes, pvalue = c(0.05, 0.1)) %>% 
      as.data.frame() %>% 
      dplyr::filter(pValue <=0.05)
    somatic_mutation_interactions_data$pValue <- round(somatic_mutation_interactions_data$pValue,3)
    somatic_mutation_interactions_data$oddsRatio <- round(somatic_mutation_interactions_data$oddsRatio,3)
    somatic_mutation_interactions_data$pAdj <- round(somatic_mutation_interactions_data$pAdj,3)

    output$somatic_mutation_interactions <- DT::renderDataTable(somatic_mutation_interactions_data,
                                            options = list(
                                              scrollX = TRUE,  # 启用横向滚动
                                              pageLength = 10, # 每页显示 10 行
                                              autoWidth = TRUE))
  })
   
  
  # somatic_mutation_drug
  observeEvent(input$somatic_mutation_drug_action,{
    
    somatic_mutation_drug_data=maftools::drugInteractions(genes=input$somatic_mutation_drug_gene,drugs=TRUE) %>% 
      as.data.frame()
    
    output$somatic_mutation_drug <- DT::renderDataTable(somatic_mutation_drug_data,
                                                                options = list(
                                                                  scrollX = TRUE,  # 启用横向滚动
                                                                  pageLength = 10, # 每页显示 10 行
                                                                  autoWidth = TRUE))
  })
  
  
  
  # somatic_mutation_survival
  observeEvent(input$somatic_mutation_survival_action,{
    
    survival_gene <- input$somatic_mutation_survival_gene
    
    output$somatic_mutation_survival <- renderPlot({
      maftools::mafSurvival(maf=maf,
                            genes=survival_gene,
                            time='OS.time',
                            Status='OS')
    },
    width = as.numeric(400),
    height = as.numeric(400))
  })
  
  output$somatic_mutation_survival_download <- downloadHandler(
    filename = function() {
      paste("somatic_mutation_survival_", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      survival_gene <- input$somatic_mutation_survival_gene
      png(file, width = 3000, height = 3000, res = 600)
      maftools::mafSurvival(maf=maf,
                            genes=survival_gene,
                            time='OS.time',
                            Status='OS')
      dev.off()
      
    }
  )
  
  
  
  
}


