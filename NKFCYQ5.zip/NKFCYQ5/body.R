body <- dashboardBody(
  add_busy_spinner(spin = "fading-circle"),
  
  #somatic_mutation_site
  tabItems(
    
  tabItem(tabName = "somatic_mutation_site",
            fluidRow(
              box(width=3,
                  column(12,
                         selectInput(
                           "somatic_mutation_site_gene", 
                           label = "Gene", 
                           choices = genes,  # 直接使用向量
                           selected = genes[100]  # 默认选中第一个元素
                         )),
                  
                  column(6,
                         actionButton("somatic_mutation_site_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                  #                    max = 400, value = 300)
                  # )
              ),
              
              box(width = 9,
                  downloadButton("somatic_mutation_site_download", "Download"),
                  hr(),
                  plotOutput("somatic_mutation_site")
              )
              
            )),
  
  
  
    #somatic_interactions
  tabItem(tabName = "somatic_interactions",
          fluidRow(
            box(width=3,
                column(12,
                       sliderInput("somatic_mutation_interactions_genes", label = "Genes Number", min = 2, 
                                   max = 50, value = 10)),
                
                column(6,
                       actionButton("somatic_mutation_interactions_action", label = "Action")),
                
                # column(12,
                #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                #                    max = 600, value = 400),
                # ),
                # column(12,
                #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                #                    max = 400, value = 300)
                # )
            ),
            
            box(width = 9,
                DT::dataTableOutput("somatic_mutation_interactions")
            )
            
         )),
    
  # somatic_mutation_drug
  tabItem(tabName = "somatic_mutation_drug",
          fluidRow(
            box(width=3,
                column(12,
                       selectInput(
                         "somatic_mutation_drug_gene", 
                         label = "Gene", 
                         choices = drugs_gene$gene_name,  # 直接使用向量
                         selected = drugs_gene$gene_name[1]  # 默认选中第一个元素
                       )
                      ),
                
                column(6,
                       actionButton("somatic_mutation_drug_action", label = "Action")),
                
                # column(12,
                #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                #                    max = 600, value = 400),
                # ),
                # column(12,
                #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                #                    max = 400, value = 300)
                # )
            ),
            
            box(width = 9,
                DT::dataTableOutput("somatic_mutation_drug")
            )
            
          )),
  
  # somatic_mutation_survival
  tabItem(tabName = "somatic_mutation_survival",
          fluidRow(
            box(width=3,
                column(12,
                       selectInput(
                         "somatic_mutation_survival_gene", 
                         label = "Gene", 
                         choices = genes,  # 直接使用向量
                         selected = genes[100]  # 默认选中第一个元素
                       )),
                
                column(6,
                       actionButton("somatic_mutation_survival_action", label = "Action")),
                
                # column(12,
                #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                #                    max = 600, value = 400),
                # ),
                # column(12,
                #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                #                    max = 400, value = 300)
                # )
            ),
            
            box(width = 9,
                downloadButton("somatic_mutation_survival_download", "Download"),
                hr(),
                plotOutput("somatic_mutation_survival")
            )
            
          )),
  
  
  tabItem(tabName = "somatic_mutation_summary",
          fluidRow(
            box(width=12,height = 2000,
                
                h5("The somatic data summary utilizes a stacked barplot to show the number of 
                   variants in each sample and generates a 
                   boxplot for summarizing variant types, with the summary 
                   organized by Variant_Classification.",downloadButton("plotmafSummary_download", "Download")),
                plotOutput("plotmafSummary"),
                hr(),
                h5("Using Oncoplot to display somatic mutation data 
                   is a better way.",downloadButton("oncoplot_download", "Download")),
                plotOutput("oncoplot"),
                hr(),
                h5("SNPs are classified into transitions and transversions.",downloadButton("plotTiTv_download", "Download")),
                plotOutput("plotTiTv"),
                hr(),
                h5("Rainfall plots present hyper - mutated genomic regions.",downloadButton("rainfallPlot_download", "Download")),
                plotOutput("rainfallPlot")

                # h3("Transition and Transversions"),
                # plotOutput("plotTiTv"),
                # h3("Rainfall plots"),
                # plotOutput("rainfallPlot")

            ) 
          )),
  # contact
  tabItem(tabName = "contact",
          fluidRow(
            box(width = 12,
                div(class = "intro-content",
                    h2("Contact Us"),
                    p("If you encounter any problems while using NKFCYQ, or have suggestions for improving the platform, please feel free to contact us through the following methods. We will respond to your inquiries as soon as possible."),
                    
                    div(class = "contact-method",
                        p(strong("Email:"), "gongyq@mail.nankai.edu.cn")  # 可替换为实际邮箱地址
                    ),
                    
                    div(class = "contact-method",
                        p(strong("WeChat:"), "gongyqnankai")  # 可替换为实际微信号
                    )
                )
            )
          )),
  
  tabItem(tabName = "Acknowledgements",
          fluidRow(
            box(width = 12,
                div(class = "intro-content",
                    h2("Acknowledgements"),
                    p("We would like to express our sincere gratitude to all individuals and organizations who have contributed to the development of NKFCYQ."),
                    
                )
            )
          ))
  
  
  
))


