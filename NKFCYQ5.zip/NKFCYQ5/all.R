

# packages ----------------------------------------------------------------



# packages
# library(tidyverse)
library(dplyr)
library(ggplot2)
library(shiny)
library(shinydashboard)
library(shinybusy)

# functions ------------------------------------------------------------------

maf <- readRDS("data/maf.rds")
drugs_gene <- data.table::fread("data/drugs_gene.csv") %>% 
  distinct(.keep_all = T)

colors1 <- ggsci::pal_simpsons("springfield")(16)
colors <- ggsci::pal_aaas("default")(10)
genes <- maf@data$Hugo_Symbol



# header ------------------------------------------------------------------

header <- dashboardHeader(title = " ")


# sidebar -----------------------------------------------------------------

sidebar <- dashboardSidebar(
  sidebarMenu(
    id = "sidebar",
    menuItem("Introduction", icon = icon("database"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ1/"),
    menuItem("miRNA Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ2/"),
    menuItem("Single-gene Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ3/"),
    menuItem("Methylation Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ4/"),
    menuItem("Somatic Mutation Analysis",
             icon = icon("bars"),
             menuSubItem("Summary", tabName = "somatic_mutation_summary"),
             menuSubItem("Mutation Site", tabName = "somatic_mutation_site"),

             menuSubItem("Survival Analysis", tabName = "somatic_mutation_survival"),
             menuSubItem("Drug-Gene Interactions", tabName = "somatic_mutation_drug")
    ),
    menuItem("Contact", icon = icon("message"), tabName = "contact"),
    menuItem("Acknowledgements", icon = icon("heart"), tabName = "Acknowledgements")
    
    
  ))


# body --------------------------------------------------------------------

body <- dashboardBody(
  add_busy_spinner(spin = "fading-circle"),
  
  #somatic_mutation_site
  tabItems(
    
    tabItem(tabName = "somatic_mutation_site",
            fluidRow(
              box(width=3,
                  column(12,
                         selectInput(
                           "somatic_mutation_site_gene", 
                           label = "Gene", 
                           choices = genes,  # 直接使用向量
                           selected = genes[100]  # 默认选中第一个元素
                         )),
                  
                  column(6,
                         actionButton("somatic_mutation_site_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                  #                    max = 400, value = 300)
                  # )
              ),
              
              box(width = 9,
                  downloadButton("somatic_mutation_site_download", "Download"),
                  hr(),
                  plotOutput("somatic_mutation_site")
              )
              
            )),
    
    
    
    #somatic_interactions
    tabItem(tabName = "somatic_interactions",
            fluidRow(
              box(width=3,
                  column(12,
                         sliderInput("somatic_mutation_interactions_genes", label = "Genes Number", min = 2, 
                                     max = 50, value = 10)),
                  
                  column(6,
                         actionButton("somatic_mutation_interactions_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                  #                    max = 400, value = 300)
                  # )
              ),
              
              box(width = 9,
                  DT::dataTableOutput("somatic_mutation_interactions")
              )
              
            )),
    
    # somatic_mutation_drug
    tabItem(tabName = "somatic_mutation_drug",
            fluidRow(
              box(width=3,
                  column(12,
                         selectInput(
                           "somatic_mutation_drug_gene", 
                           label = "Gene", 
                           choices = drugs_gene$gene_name,  # 直接使用向量
                           selected = drugs_gene$gene_name[1]  # 默认选中第一个元素
                         )
                  ),
                  
                  column(6,
                         actionButton("somatic_mutation_drug_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                  #                    max = 400, value = 300)
                  # )
              ),
              
              box(width = 9,
                  DT::dataTableOutput("somatic_mutation_drug")
              )
              
            )),
    
    # somatic_mutation_survival
    tabItem(tabName = "somatic_mutation_survival",
            fluidRow(
              box(width=3,
                  column(12,
                         selectInput(
                           "somatic_mutation_survival_gene", 
                           label = "Gene", 
                           choices = genes,  # 直接使用向量
                           selected = genes[100]  # 默认选中第一个元素
                         )),
                  
                  column(6,
                         actionButton("somatic_mutation_survival_action", label = "Action")),
                  
                  # column(12,
                  #        sliderInput("gene_expression_width", label = "Width", min = 0, 
                  #                    max = 600, value = 400),
                  # ),
                  # column(12,
                  #        sliderInput("gene_expression_height", label = "Height", min = 0, 
                  #                    max = 400, value = 300)
                  # )
              ),
              
              box(width = 9,
                  downloadButton("somatic_mutation_survival_download", "Download"),
                  hr(),
                  plotOutput("somatic_mutation_survival")
              )
              
            )),
    
    
    tabItem(tabName = "somatic_mutation_summary",
            fluidRow(
              box(width=12,height = 2000,
                  
                  h5("The somatic data summary utilizes a stacked barplot to show the number of 
                   variants in each sample and generates a 
                   boxplot for summarizing variant types, with the summary 
                   organized by Variant_Classification.",downloadButton("plotmafSummary_download", "Download")),
                  plotOutput("plotmafSummary"),
                  hr(),
                  h5("Using Oncoplot to display somatic mutation data 
                   is a better way.",downloadButton("oncoplot_download", "Download")),
                  plotOutput("oncoplot"),
                  hr(),
                  h5("SNPs are classified into transitions and transversions.",downloadButton("plotTiTv_download", "Download")),
                  plotOutput("plotTiTv"),
                  hr(),
                  h5("Rainfall plots present hyper - mutated genomic regions.",downloadButton("rainfallPlot_download", "Download")),
                  plotOutput("rainfallPlot")
                  
                  # h3("Transition and Transversions"),
                  # plotOutput("plotTiTv"),
                  # h3("Rainfall plots"),
                  # plotOutput("rainfallPlot")
                  
              ) 
            )),
    # contact
    tabItem(tabName = "contact",
            fluidRow(
              box(width = 12,
                  div(class = "intro-content",
                      h2("Contact Us"),
                      p("If you encounter any problems while using NKFCYQ, or have suggestions for improving the platform, please feel free to contact us through the following methods. We will respond to your inquiries as soon as possible."),
                      
                      div(class = "contact-method",
                          p(strong("Email:"), "gongyq@mail.nankai.edu.cn")  # 可替换为实际邮箱地址
                      ),
                      
                      div(class = "contact-method",
                          p(strong("WeChat:"), "gongyqnankai")  # 可替换为实际微信号
                      )
                  )
              )
            )),
    
    tabItem(tabName = "Acknowledgements",
            fluidRow(
              box(width = 12,
                  div(class = "intro-content",
                      h2("Acknowledgements"),
                      p("We would like to express our sincere gratitude to all individuals and organizations who have contributed to the development of NKFCYQ."),
                      
                  )
              )
            ))
    
    
    
  ))




# server ------------------------------------------------------------------

# server ------------------------------------------------------------------

server <- function(input, output, session) {
  
  # 验证密码
  # res_auth <- secure_server(
  #   check_credentials = check_credentials(credentials)
  # )
  
  
  # summary
  
  output$plotmafSummary <- renderPlot({
    maftools::plotmafSummary(maf = maf, 
                             rmOutlier = TRUE, 
                             addStat = 'median', 
                             dashboard = TRUE, 
                             titvRaw = FALSE)
  }
  )
  
  output$plotmafSummary_download <- downloadHandler(
    filename = function() {
      paste("mafSummary__", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      png(file, width = 2000, height = 2000, res = 300)
      maftools::plotmafSummary(maf = maf, 
                               rmOutlier = TRUE, 
                               addStat = 'median', 
                               dashboard = TRUE, 
                               titvRaw = FALSE)
      dev.off()
      
    }
  )
  
  
  
  output$oncoplot <- renderPlot({
    maftools::oncoplot(maf, top = 20)
  }
  )
  
  output$oncoplot_download <- downloadHandler(
    filename = function() {
      paste("oncoplot__", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      png(file, width = 2000, height = 2000, res = 300)
      maftools::oncoplot(maf, top = 20)
      dev.off()
      
    }
  )
  
  
  output$plotTiTv<- renderPlot({
    laml.titv <- maftools::titv(maf, plot = F, useSyn = TRUE)
    maftools::plotTiTv(res = laml.titv)
  }
  )
  
  output$plotTiTv_download <- downloadHandler(
    filename = function() {
      paste("TiTv__", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      png(file, width = 2000, height = 2000, res = 300)
      laml.titv <- maftools::titv(maf, plot = F, useSyn = TRUE)
      maftools::plotTiTv(res = laml.titv)
      dev.off()
      
    }
  )
  
  
  
  output$rainfallPlot<- renderPlot({
    maftools::rainfallPlot(maf = maf, detectChangePoints = TRUE, pointSize = 0.4)
  }
  )
  
  output$rainfallPlot_download <- downloadHandler(
    filename = function() {
      paste("rainfallPlot__", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      png(file, width = 2000, height = 2000, res = 300)
      maftools::rainfallPlot(maf = maf, detectChangePoints = TRUE, pointSize = 0.4)
      dev.off()
      
    }
  )
  
  # somatic_mutation_site
  observeEvent(input$somatic_mutation_site_action,{
    
    site_gene <- input$somatic_mutation_site_gene
    
    output$somatic_mutation_site <- renderPlot({
      maftools::lollipopPlot(maf=maf,
                             gene=site_gene,
                             # AACol="HGVSp_Short",
                             showMutationRate=TRUE)
    },
    width = as.numeric(600),
    height = as.numeric(120))
  })
  
  output$somatic_mutation_site_download <- downloadHandler(
    filename = function() {
      paste("somatic_mutation_site_", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      png(file, width = 20000, height = 4000, res = 600)
      maftools::lollipopPlot(maf=maf,
                             gene=input$somatic_mutation_site_gene,
                             # AACol="HGVSp_Short",
                             showMutationRate=TRUE)
      dev.off()
      
    }
  )
  
  
  
  # somatic_interactions
  observeEvent(input$somatic_mutation_interactions_action,{
    
    somatic_mutation_interactions_data <- maftools::somaticInteractions(maf = maf, top = input$somatic_mutation_interactions_genes, pvalue = c(0.05, 0.1)) %>% 
      as.data.frame() %>% 
      dplyr::filter(pValue <=0.05)
    somatic_mutation_interactions_data$pValue <- round(somatic_mutation_interactions_data$pValue,3)
    somatic_mutation_interactions_data$oddsRatio <- round(somatic_mutation_interactions_data$oddsRatio,3)
    somatic_mutation_interactions_data$pAdj <- round(somatic_mutation_interactions_data$pAdj,3)
    
    output$somatic_mutation_interactions <- DT::renderDataTable(somatic_mutation_interactions_data,
                                                                options = list(
                                                                  scrollX = TRUE,  # 启用横向滚动
                                                                  pageLength = 10, # 每页显示 10 行
                                                                  autoWidth = TRUE))
  })
  
  
  # somatic_mutation_drug
  observeEvent(input$somatic_mutation_drug_action,{
    
    somatic_mutation_drug_data=maftools::drugInteractions(genes=input$somatic_mutation_drug_gene,drugs=TRUE) %>% 
      as.data.frame()
    
    output$somatic_mutation_drug <- DT::renderDataTable(somatic_mutation_drug_data,
                                                        options = list(
                                                          scrollX = TRUE,  # 启用横向滚动
                                                          pageLength = 10, # 每页显示 10 行
                                                          autoWidth = TRUE))
  })
  
  
  
  # somatic_mutation_survival
  observeEvent(input$somatic_mutation_survival_action,{
    
    survival_gene <- input$somatic_mutation_survival_gene
    
    output$somatic_mutation_survival <- renderPlot({
      maftools::mafSurvival(maf=maf,
                            genes=survival_gene,
                            time='OS.time',
                            Status='OS')
    },
    width = as.numeric(400),
    height = as.numeric(400))
  })
  
  output$somatic_mutation_survival_download <- downloadHandler(
    filename = function() {
      paste("somatic_mutation_survival_", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      survival_gene <- input$somatic_mutation_survival_gene
      png(file, width = 3000, height = 3000, res = 600)
      maftools::mafSurvival(maf=maf,
                            genes=survival_gene,
                            time='OS.time',
                            Status='OS')
      dev.off()
      
    }
  )
  
  
  
  
}



# app ---------------------------------------------------------------------


ui <- dashboardPage(
  # dashboardHeader(title = "Tianjin First Central Hospital"),
  header, sidebar, body)

# ui <- secure_app(ui)
# options(shiny.maxRequestSize = 60 * 1024^2)

shinyApp(ui, server)



