maf <- readRDS("data/maf.rds")
drugs_gene <- data.table::fread("data/drugs_gene.csv") %>% 
  distinct(.keep_all = T)

colors1 <- ggsci::pal_simpsons("springfield")(16)
colors <- ggsci::pal_aaas("default")(10)
genes <- maf@data$Hugo_Symbol

