# packages ----------------------------------------------------------------

library(shiny)
library(shinybusy)
library(shinydashboard)

# header ------------------------------------------------------------------

header <- dashboardHeader(title = "NKFCYQ")


# sidebar -----------------------------------------------------------------

sidebar <- dashboardSidebar(
  sidebarMenu(
    id = "sidebar",
    menuItem("Introduction", icon = icon("database"), tabName = "introduction"),
    menuItem("miRNA Analysis", icon = icon("wine-glass"),href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ2/"),
    menuItem("Single-gene Analysis",icon = icon("wine-glass"),href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ3/"),
    menuItem("Methylation Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ4/"),
    menuItem("Somatic Mutation Analysis", icon = icon("wine-glass"), href = "http://xiyoucloud.pro:25653/shiny%20apps/NKFCYQ5/"),
    menuItem("Contact", icon = icon("message"), tabName = "contact"),
    menuItem("Acknowledgements", icon = icon("heart"), tabName = "Acknowledgements")
  )
)



# body --------------------------------------------------------------------

body <- dashboardBody(
  # add_busy_spinner(spin = "fading-circle"),
  # 调整后的样式，减少缩进和间距
  tags$style(HTML("
    .intro-content {
      padding: 15px 0px;  /* 仅上下留白，左右不留白 */
      line-height: 1.6;
    }
    .intro-content h2 {
      color: #2c3e50;
      margin-top: 20px;
      margin-bottom: 15px;
      border-bottom: 1px solid #eee;
      padding-bottom: 8px;
    }
    .intro-content h3 {
      color: #34495e;
      margin-top: 20px;
      margin-bottom: 10px;
      margin-left: 0;  /* 确保标题顶格 */
    }
    .intro-content p {
      margin: 0 0 10px 0;  /* 段落顶格，减少底部间距 */
    }
    .intro-content ul {
      margin: 0 0 15px 20px;  /* 仅左侧少量缩进，减少上下间距 */
      padding: 0;  /* 去除默认内边距 */
    }
    .intro-content li {
      margin: 5px 0;  /* 减少列表项间距 */
    }
    .box .box-body {
      padding: 10px 15px;  /* 减少盒子内边距 */
    }
    .contact-method {
      margin-bottom: 15px;
    }
  ")),
  tabItems(
    # introduction
    tabItem(tabName = "introduction",
            fluidRow(
              box(width = 12,
                  div(class = "intro-content",
                      h2("Introduction"),
                      p("Welcome to NKFCYQ. It integrates resources related to liver cancer research, covering data and analysis tools at multiple molecular levels including miRNA, genes, methylation, and somatic mutations. The website contains 4 core analysis modules, with specific functions as follows:"),
                      
                      h3("1. miRNA Analysis"),
                      p("The miRNA analysis module provides the following functionalities:"),
                      tags$ul(
                        tags$li(strong("miRNA-Gene Prediction:"), " Input an miRNA to identify its potential target genes"),
                        tags$li(strong("Gene-miRNA Prediction:"), " Input a functional gene to find miRNAs that regulate it"),
                        tags$li(strong("Expression Analysis/Paired Expression Analysis:"), " Compare miRNA expression differences across samples or between paired groups"),
                        tags$li(strong("Survival Analysis:"), " Correlate miRNA expression levels with patient survival outcomes"),
                        tags$li(strong("ROC Analysis:"), " Assess the diagnostic value of miRNAs for liver cancer")
                      ),
                      
                      h3("2. Single-gene Analysis"),
                      p("The single-gene analysis module includes these features:"),
                      tags$ul(
                        tags$li(strong("Correlation Analysis:"), " Analyze expression correlations between a target gene and other genes"),
                        tags$li(strong("Expression Analysis/Paired Expression Analysis:"), " Evaluate gene expression differences across samples or paired groups"),
                        tags$li(strong("Survival Analysis:"), " Link gene expression levels to patient survival prognosis"),
                        tags$li(strong("ROC Analysis:"), " Determine the potential of a gene as a liver cancer diagnostic marker"),
                        tags$li(strong("Drug Sensitivity Analysis:"), " Compare drug sensitivity across groups stratified by gene expression"),
                        tags$li(strong("Immune Infiltration Analysis:"), " Investigate immune cell infiltration patterns across groups stratified by the target gene's expression levels "),
                        tags$li(strong("Single-cell Analysis:"), " Explore gene expression patterns across different cell types")
                      ),
                      
                      h3("3. Methylation Analysis"),
                      p("The methylation analysis module offers the following capabilities:"),
                      tags$ul(
                        tags$li(strong("Gene-CpG Mapping:"), " Search for CpG methylation sites associated with a specific gene"),
                        tags$li(strong("Expression Analysis:"), " Analyze methylation level differences across various samples/conditions"),
                        tags$li(strong("Paired Expression Analysis:"), " Compare methylation levels between tumor and adjacent normal tissues from the same patient"),
                        tags$li(strong("Survival Analysis:"), " Investigate associations between methylation levels and patient survival"),
                        tags$li(strong("ROC Analysis:"), " Evaluate methylation patterns as diagnostic markers for liver cancer")
                      ),
                      
                      h3("4. Somatic Mutation Analysis"),
                      p("The somatic mutation analysis module provides these tools:"),
                      tags$ul(
                        tags$li(strong("Summary:"), " View a concise overview and statistical summary of somatic mutation data"),
                        tags$li(strong("Mutation Site:"), " Visualize mutation locations within specific genes"),
                        tags$li(strong("Survival Analysis:"), " Analyze how gene mutation status correlates with survival outcomes"),
                        tags$li(strong("Drug-Gene Interactions:"), " Find drugs targeting specific mutated genes")
                      )
                  )
              )
            )),
    
    # contact
    tabItem(tabName = "contact",
            fluidRow(
              box(width = 12,
                  div(class = "intro-content",
                      h2("Contact Us"),
                      p("If you encounter any problems while using NKFCYQ, or have suggestions for improving the platform, please feel free to contact us through the following methods. We will respond to your inquiries as soon as possible."),
                      
                      div(class = "contact-method",
                          p(strong("Email:"), "gongyq@mail.nankai.edu.cn")  # 可替换为实际邮箱地址
                      ),
                      
                      div(class = "contact-method",
                          p(strong("WeChat:"), "gongyqnankai")  # 可替换为实际微信号
                      )
                  )
              )
            )),
    
    tabItem(tabName = "Acknowledgements",
            fluidRow(
              box(width = 12,
                  div(class = "intro-content",
                      h2("Acknowledgements"),
                      p("We would like to express our sincere gratitude to all individuals and organizations who have contributed to the development of NKFCYQ."),
                     
                  )
              )
            ))
    
    
    
  )
)


# server ------------------------------------------------------------------

server <- function(input, output) {
  # 无需额外服务器逻辑
}


# app ---------------------------------------------------------------------

ui <- dashboardPage(
  header, sidebar, body)

# options(shiny.maxRequestSize = 60 * 1024^2)

shinyApp(ui, server)
